CREATE VIEW `alertas` AS

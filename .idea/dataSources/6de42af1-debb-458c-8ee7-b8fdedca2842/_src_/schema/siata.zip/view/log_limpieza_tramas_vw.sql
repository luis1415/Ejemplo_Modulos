CREATE VIEW `log_limpieza_tramas_vw` AS
